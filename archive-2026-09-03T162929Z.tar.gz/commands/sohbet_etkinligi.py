import json
import random
import logging
from pathlib import Path
from datetime import datetime, timezone

import discord
from discord.ext import commands, tasks


logger = logging.getLogger("sohbet_etkinligi")


# =========================================================
# AYARLAR
# =========================================================

BASE_DIR = Path(__file__).resolve().parent.parent
SORULAR_DOSYASI = BASE_DIR / "sorular" / "sorular.json"

KANAL_ID = 1531398570169860236
ROL_ID = 1287047005054570528


# =========================================================
# SORULARI YÜKLE
# =========================================================

def sorulari_yukle():
    try:
        with open(SORULAR_DOSYASI, "r", encoding="utf-8") as dosya:
            sorular = json.load(dosya)

        if not isinstance(sorular, list):
            logger.error("❌ sorular.json bir liste olmalı.")
            return []

        return sorular

    except FileNotFoundError:
        logger.error(
            f"❌ sorular.json bulunamadı: {SORULAR_DOSYASI}"
        )

    except json.JSONDecodeError as e:
        logger.error(
            f"❌ sorular.json geçersiz JSON: {e}"
        )

    except Exception:
        logger.exception(
            "❌ Sorular yüklenirken hata oluştu."
        )

    return []


# =========================================================
# CHAT EVENT MESAJI
# =========================================================

async def soru_gonder(bot):
    kanal = bot.get_channel(KANAL_ID)

    if kanal is None:
        logger.error(
            f"❌ Kanal bulunamadı. KANAL_ID = {KANAL_ID}"
        )
        return False

    sorular = sorulari_yukle()

    if not sorular:
        logger.error(
            "❌ JSON içerisinde hiç soru bulunamadı."
        )
        return False

    soru = random.choice(sorular)

    if not isinstance(soru, dict):
        logger.error(
            "❌ JSON içerisindeki soru formatı hatalı."
        )
        return False

    metin = soru.get("soru")

    if not metin:
        logger.error(
            "❌ Seçilen soru içerisinde 'soru' alanı yok."
        )
        return False

    embed = discord.Embed(
        title="💬 Chat Event",
        description=f"**Question:** {metin}"
    )

    try:
        await kanal.send(
            content=f"<@&{ROL_ID}>",
            embed=embed
        )

        logger.info(
            f"✅ Chat Event gönderildi: {metin}"
        )

        return True

    except discord.Forbidden:
        logger.error(
            "❌ Botun kanala mesaj gönderme yetkisi yok "
            "veya rolü etiketleyemiyor."
        )

    except discord.HTTPException:
        logger.exception(
            "❌ Discord mesaj gönderirken HTTP hatası verdi."
        )

    except Exception:
        logger.exception(
            "❌ Soru gönderilirken bilinmeyen hata oluştu."
        )

    return False


# =========================================================
# OTOMATİK CHAT EVENT
# =========================================================

@tasks.loop(hours=2)
async def sohbet_etkinligi_zamanlayici():

    bot = sohbet_etkinligi_zamanlayici.bot

    try:
        await soru_gonder(bot)

    except Exception:
        logger.exception(
            "❌ Zamanlanmış Chat Event sırasında hata oluştu."
        )


# =========================================================
# ZAMANLAYICI HAZIRLIK
# =========================================================

@sohbet_etkinligi_zamanlayici.before_loop
async def zamanlayiciyi_beklet():

    bot = sohbet_etkinligi_zamanlayici.bot

    await bot.wait_until_ready()

    logger.info(
        "⏰ Chat Event zamanlayıcısı hazır."
    )


# =========================================================
# KALAN SÜRE HESAPLAMA
# =========================================================

def kalan_sureyi_al():

    try:
        sonraki = sohbet_etkinligi_zamanlayici.next_iteration

        if sonraki is None:
            return None

        simdi = datetime.now(timezone.utc)

        kalan = sonraki - simdi

        if kalan.total_seconds() <= 0:
            return None

        return kalan

    except Exception:
        logger.exception(
            "❌ Chat Event kalan süre hesaplanırken hata oluştu."
        )
        return None


def sureyi_formatla(sure):

    toplam_saniye = int(sure.total_seconds())

    gun = toplam_saniye // 86400
    toplam_saniye %= 86400

    saat = toplam_saniye // 3600
    toplam_saniye %= 3600

    dakika = toplam_saniye // 60
    saniye = toplam_saniye % 60

    parcalar = []

    if gun > 0:
        parcalar.append(f"{gun} gün")

    if saat > 0:
        parcalar.append(f"{saat} saat")

    if dakika > 0:
        parcalar.append(f"{dakika} dakika")

    parcalar.append(f"{saniye} saniye")

    return " ".join(parcalar)


# =========================================================
# KOMUTLAR
# =========================================================

def setup(bot):

    logger.info(
        "🔧 Sohbet etkinliği modülü yükleniyor..."
    )

    # Timer'ın kullanacağı bot
    sohbet_etkinligi_zamanlayici.bot = bot


    # -----------------------------------------------------
    # PREFIX TEST KOMUTU
    # -----------------------------------------------------

    @bot.command(name="chat-test")
    async def chat_test(ctx: commands.Context):

        logger.info(
            f"🧪 !chat-test kullanıldı: "
            f"{ctx.author} ({ctx.author.id})"
        )

        basarili = await soru_gonder(bot)

        if basarili:
            await ctx.send(
                "✅ Chat Event test mesajı gönderildi."
            )
        else:
            await ctx.send(
                "❌ Chat Event gönderilemedi. "
                "bot.log dosyasını kontrol et."
            )


    # -----------------------------------------------------
    # PREFIX TIMER KOMUTU
    # -----------------------------------------------------

    @bot.command(name="chat-timer")
    async def chat_timer(ctx: commands.Context):

        logger.info(
            f"⏱️ !chat-timer kullanıldı: "
            f"{ctx.author} ({ctx.author.id})"
        )

        if not sohbet_etkinligi_zamanlayici.is_running():

            await ctx.send(
                "❌ Chat Event zamanlayıcısı şu anda çalışmıyor."
            )

            return

        kalan = kalan_sureyi_al()

        if kalan is None:

            await ctx.send(
                "⚠️ Zamanlayıcının bir sonraki çalışma zamanı "
                "henüz hesaplanamadı."
            )

            return

        embed = discord.Embed(
            title="⏰ Chat Event Timer",
            description=(
                f"**Sonraki Chat Event'e kalan süre:**\n"
                f"## {sureyi_formatla(kalan)}"
            )
        )

        embed.add_field(
            name="🔄 Durum",
            value="🟢 Aktif",
            inline=True
        )

        embed.add_field(
            name="⏱️ Aralık",
            value="2 saat",
            inline=True
        )

        await ctx.send(embed=embed)


    # -----------------------------------------------------
    # SLASH TEST KOMUTU
    # -----------------------------------------------------

    @bot.tree.command(
        name="chat_test",
        description="Chat Event sistemini test eder."
    )
    async def chat_test_slash(
        interaction: discord.Interaction
    ):

        logger.info(
            f"🧪 /chat_test kullanıldı: "
            f"{interaction.user} ({interaction.user.id})"
        )

        await interaction.response.defer(
            ephemeral=True
        )

        basarili = await soru_gonder(bot)

        if basarili:
            await interaction.followup.send(
                "✅ Chat Event test mesajı gönderildi.",
                ephemeral=True
            )
        else:
            await interaction.followup.send(
                "❌ Chat Event gönderilemedi. "
                "bot.log dosyasını kontrol et.",
                ephemeral=True
            )


    # -----------------------------------------------------
    # SLASH TIMER KOMUTU
    # -----------------------------------------------------

    @bot.tree.command(
        name="chat_timer",
        description="Bir sonraki Chat Event'e kalan süreyi gösterir."
    )
    async def chat_timer_slash(
        interaction: discord.Interaction
    ):

        logger.info(
            f"⏱️ /chat_timer kullanıldı: "
            f"{interaction.user} ({interaction.user.id})"
        )

        if not sohbet_etkinligi_zamanlayici.is_running():

            await interaction.response.send_message(
                "❌ Chat Event zamanlayıcısı şu anda çalışmıyor.",
                ephemeral=True
            )

            return

        kalan = kalan_sureyi_al()

        if kalan is None:

            await interaction.response.send_message(
                "⚠️ Zamanlayıcının bir sonraki çalışma zamanı "
                "henüz hesaplanamadı.",
                ephemeral=True
            )

            return

        embed = discord.Embed(
            title="⏰ Chat Event Timer",
            description=(
                f"**Sonraki Chat Event'e kalan süre:**\n"
                f"## {sureyi_formatla(kalan)}"
            )
        )

        embed.add_field(
            name="🔄 Durum",
            value="🟢 Aktif",
            inline=True
        )

        embed.add_field(
            name="⏱️ Aralık",
            value="2 saat",
            inline=True
        )

        await interaction.response.send_message(
            embed=embed,
            ephemeral=True
        )


    # -----------------------------------------------------
    # OTOMATİK ZAMANLAYICIYI BAŞLAT
    # -----------------------------------------------------

    async def sohbet_etkinligi_baslat():
        if not sohbet_etkinligi_zamanlayici.is_running():
            sohbet_etkinligi_zamanlayici.start()
            logger.info(
                "✅ Chat Event zamanlayıcısı başlatıldı."
            )

    bot.add_listener(
        sohbet_etkinligi_baslat,
        "on_ready"
    )


    logger.info(
        "🧪 Test komutları hazır: "
        "!chat-test /chat_test"
    )

    logger.info(
        "⏱️ Timer komutları hazır: "
        "!chat-timer /chat_timer"
    )